# Solar Boiler V4b — atmospheric relief steam readability

This source-safe additive derivative starts with the **verified V4 wood-first** Blender model. It adjusts only the animated 12-lobe steam at the open atmosphere-facing relief nozzle; the source V4 is untouched. The 3×2 wooden barrel, wood planks on seven conduit routes, two polished timber parabolic collectors, restrained focal tube heating, original three metal Factorio fluid connections and fixed 45° camera are unchanged.

The earlier V4 relief gas was a noise-feathered **real Blender Volume Principled** shader but only changed 22 RGB pixels in the 256px Cycles comparison, so it did not satisfy the requested visual standard. V4b increases gas extinction and plume height/width (not hard opacity), retains the three-dimensional falloff reaching zero inside each mesh boundary, and keeps 12 staggered deforming 3D wisps at a single real outlet. The same-frame off/on comparisons must exceed 70 affected pixels at 256px and three at downsampled native 64px. Failure blocks publication; these thresholds are diagnostic requirements, not approval claims.

A bounded pilot renders 4 idle, 4 working, 16 North motion samples and 2 steam isolation images. Independent Blender reopen audits preserved wood geometry, three full-bore pipe faces, volume shader IDs, and exact cyclic motion. No game sprites, gameplay, recipes, FMPL source, previous models, or new workflow are modified. This is an independent visual review candidate, not a final user-accepted asset.

Reproduce on existing Blender-capable runner using `refine_steam_v4b.py`, `verify_steam_v4b.py` and `make_steam_proof.py` in that order. Output must be a new empty `generated-v4b/` directory.
