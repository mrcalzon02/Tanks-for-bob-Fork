#!/usr/bin/env python3
"""Render-backed 64px steam isolation, cardinal review, animated North 16 sample GIF."""
from pathlib import Path
from PIL import Image,ImageChops,ImageDraw,ImageFont
import argparse,hashlib,json

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def difference_pixels(a,b,threshold):
    aa=a.convert('RGB');bb=b.convert('RGB');diff=ImageChops.difference(aa,bb)
    return sum(1 for r,g,b in diff.getdata() if max(r,g,b)>=threshold)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path)
    args=p.parse_args();out=args.output.resolve()
    n=json.loads((out/'native-reopen-qa.json').read_text())
    r=json.loads((out/'build-report.json').read_text())
    assert n['passed'] and len(r['renders'])==24
    imgs={}
    for item in r['renders']:
        path=out/item['file'];assert sha(path)==item['sha256']
        with Image.open(path) as im:
            assert im.mode=='RGBA' and im.size==(256,256)
            px=im.copy()
        b=px.getchannel('A').getbbox()
        assert b and b[0]>0 and b[1]>0 and b[2]<256 and b[3]<256,(path.name,b)
        imgs[path.name]=px
    with Image.open(out/'steam-isolation-off.png') as x:
        off=x.convert('RGBA')
    with Image.open(out/'steam-isolation-on.png') as x:
        on=x.convert('RGBA')
    changed256=difference_pixels(off,on,9)
    down_off=off.resize((64,64),Image.Resampling.LANCZOS)
    down_on=on.resize((64,64),Image.Resampling.LANCZOS)
    changed64=difference_pixels(down_off,down_on,4)
    assert changed256>=70,('Steam still invisible at 256px',changed256)
    assert changed64>=3,('Steam still invisible at game 64px',changed64)
    native=imgs['working-d00.png'].resize((64,64),Image.Resampling.LANCZOS)
    native.save(out/'north-working-native-64.png')
    back=(24,29,33)
    sheet=Image.new('RGB',(1120,815),back);draw=ImageDraw.Draw(sheet);font=ImageFont.load_default()
    draw.text((18,14),'SOLAR BOILER V4b / TRUE SOFT TURBULENT STEAM / REAL BLENDER CYCLES PROOF',font=font,fill='white')
    draw.text((18,33),'Survival wooden barrel / crude bentwood conduits / polished wood reflectors / atmospheric nozzle only',font=font,fill=(218,217,206))
    for i,name in enumerate(('north','east','south','west')):
        x=18+i*275
        draw.text((x+4,55),name.upper(),font=font,fill='white')
        for row,state in enumerate(('idle','working')):
            y=75+row*280
            im=imgs[f'{state}-d{i:02d}.png']
            sheet.paste(im,(x,y),im)
            draw.text((x+5,y+259),state,font=font,fill='white')
        tiny=imgs[f'working-d{i:02d}.png'].resize((64,64),Image.Resampling.LANCZOS)
        sheet.paste(tiny,(x+12,662),tiny)
        draw.text((x+86,696),'64px',font=font,fill='white')
    draw.text((18,777),f'Actual same-frame steam isolation: {changed256} changed pixels at 256px, {changed64} at 64px',font=font,fill=(218,218,218))
    sheet.save(out/'review-four-directions.png',optimize=True)
    src=[imgs[f'loop-d00-f{k:03d}.png'] for k in range(16)]
    unique=len({hashlib.sha256(x.tobytes()).hexdigest() for x in src})
    assert unique>=12
    frames=[]
    for im in src:
        bg=Image.new('RGBA',(256,256),(*back,255));bg.alpha_composite(im)
        frames.append(bg.convert('RGB'))
    frames[0].save(out/'working-north-v4b-preview.gif',save_all=True,append_images=frames[1:],duration=125,loop=0,disposal=2)
    with Image.open(out/'working-north-v4b-preview.gif') as g:assert g.n_frames==16
    qa={'schema':'tanks.v4b.pixel-proof','passed':True,'native_reopen':True,'actual_blender_views':24,
        'same_frame_steam_pixels_256':changed256,'same_frame_steam_pixels_64':changed64,
        'working_unique_frames':unique,'wood_structure_unchanged':True,
        'preview_png_sha256':sha(out/'review-four-directions.png'),
        'preview_gif_sha256':sha(out/'working-north-v4b-preview.gif'),
        'visual_approved':False,'game_integrated':False}
    (out/'proof-qa.json').write_text(json.dumps(qa,indent=2)+'\n')
    print('SOLAR_V4B_REAL_CYCLES_STEAM_READABILITY_PASSED',changed256,changed64,flush=True)

if __name__=='__main__':main()
