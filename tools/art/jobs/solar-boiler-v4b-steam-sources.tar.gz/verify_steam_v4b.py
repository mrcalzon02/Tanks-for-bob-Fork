#!/usr/bin/env python3
"""Separate Blender process: V4b native source/port/wood/vapor reopen QA."""
from pathlib import Path
import argparse,hashlib,json,math,sys
import bpy
from mathutils import Vector

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from refine_steam_v4b import sha,camera_record,WORK


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True,type=Path)
    opts=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:])
    out=opts.output.resolve()
    file=out/'solar-boiler-v4b.blend'
    rpt=json.loads((out/'build-report.json').read_text())
    base=HERE.parent/'generated-v4'/'solar-boiler-v4.blend'
    assert Path(bpy.data.filepath).resolve()==file
    assert sha(file)==rpt['native_sha256'] and sha(base)==rpt['source_v4_sha256']
    s=bpy.context.scene
    root=bpy.data.objects['EXPORT | rotate Solar Boiler model, never camera']
    assert list(root['footprint_tiles'])==[3,2]
    s.frame_set(0);root.rotation_euler.z=0;bpy.context.view_layer.update()
    assert camera_record(s)==rpt['camera']
    assert s.camera.data.type=='ORTHO' and len([o for o in bpy.data.objects if o.type=='CAMERA'])==1
    assert bpy.data.collections['REFERENCE ONLY | adjacent matched 1-tile pipe fixtures'].hide_render
    assert sum(o.get('wood_role')=='rough bowed barrel planking' for o in s.objects)==18
    assert sum(o.get('wood_role')=='curved planking on hollow conduit' for o in s.objects)>=60
    mirrors=[o for o in s.objects if o.get('wood_role')=='polished actual wood reflective parabola']
    assert len(mirrors)==2
    ports=json.loads((HERE.parent/'v1'/'port-contract.json').read_text())['ports']
    checked=[]
    for port in ports:
        name=port['id'];P=Vector(port['blender_flange_xyz']);N=Vector(port['normal_xyz'])
        ob=bpy.data.objects[f'PORT | {name} | full machine collar']
        ref=bpy.data.objects[f'REF | {name} | near matching collar']
        def face(obj):return [obj.matrix_world@v.co for v in obj.data.vertices if abs((obj.matrix_world@v.co-P).dot(N))<1e-6]
        a=face(ob);b=face(ref)
        assert len(a)==len(b)==128
        err=max(min((v-w).length for w in b) for v in a)
        assert err<1e-5,(name,err)
        checked.append({'port':name,'mating_residual':err})
    for id in ('ferrocrete','ferrocrete_light','ferrocrete_dark'):
        mat=bpy.data.materials['TP Library | '+id]
        assert len([n for n in mat.node_tree.nodes if n.type=='TEX_IMAGE' and n.image and n.image.packed_file])==3
    for id in ('SOLAR V4 | real feathered steam volume','SOLAR V4 | soft thin steam halo'):
        mat=bpy.data.materials[id]
        assert mat['solar_v4b_density_gain']>=3.6
        assert any(n.bl_idname=='ShaderNodeVolumePrincipled' for n in mat.node_tree.nodes)
        assert mat.node_tree.nodes['V4 calibrated steam optical density'].inputs[1].default_value>=3.6
    lobes=[o for o in s.objects if o.type=='MESH' and o.name.startswith('STEAM V4 | open relief | lobe ')]
    assert len(lobes)==12
    for o in lobes:
        assert o['emitter']=='open pressure relief valve only'
        assert o.get('solar_v4b_scattered_steam') is True
        s.frame_set(1);initial=o.scale.copy()
        s.frame_set(97);assert (o.scale-initial).length<1e-5
        s.frame_set(0);assert o.hide_render
    for o in s.objects:
        if o.get('wood_role') and o.type=='MESH':
            assert not (o.hide_render and o.name.startswith('WOOD V4 |')),'V4 visible timber unexpectedly hidden'
    for item in rpt['renders']:
        assert sha(out/item['file'])==item['sha256']
    assert len(rpt['renders'])==24
    for item in rpt.get('isolation',[]):
        assert sha(out/item['file'])==item['sha256']
    assert len(rpt['isolation'])==2
    result={'schema':'tanks.v4b.native-reopen','passed':True,'source_v4_sha256':sha(base),
            'one_camera':True,'full_port_mating':checked,'wood_staves':18,'bentwood_conduits':65,
            'wood_parabolic_mirrors':2,'volume_lobes':12,'emitter':'open relief nozzle only',
            'frame97_matches_frame1':True,'preserves_wood_and_approved_fmpl':True,
            'visual_approved':False,'game_integrated':False}
    (out/'native-reopen-qa.json').write_text(json.dumps(result,indent=2)+'\n')
    print('SOLAR_V4B_REOPEN_WOOD_AND_REAL_STEAM_PASSED',flush=True)

if __name__=='__main__':main()
