#!/usr/bin/env python3
"""Solar Boiler V4b: readable turbulent FMPL-style relief vapor, source-safe.

Derives real verified V4 Blender model; improves ONLY the noise-feathered
atmospheric relief volumetrics. No steam at any water/pipe connection.
The 18 wooden barrel staves, wooden planks, polished timber parabolic mirrors,
three full-bore native pipe ports and original camera are unchanged.
"""
from __future__ import annotations
import argparse, hashlib, json, math, struct, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'generated-v4'/'solar-boiler-v4.blend'
SOURCE_REPORT=HERE.parent/'generated-v4'/'build-report.json'
WORK=tuple(range(1,92,6))
DIRECTIONS=(0,90,180,270)


def sha(file):return hashlib.sha256(Path(file).read_bytes()).hexdigest()


def self_check():
    record=json.loads(SOURCE_REPORT.read_text())
    assert sha(SOURCE)==record['native_sha256']
    assert record['barrel_staves']==18 and record['stave_conduit_planks']>=60
    assert record['steam_lobes']==12 and record['steam_sources']==['open-pressure-relief-nozzle']
    assert 16==len(WORK) and WORK[0]==1 and WORK[-1]==91
    assert abs(math.sin(math.tau)-math.sin(0))<1e-12
    print('SOLAR_V4B_SOURCE_AND_CLOSED_LOOP_PASS',flush=True)


def fingerprint(o):
    h=hashlib.sha256()
    for v in o.data.vertices:h.update(struct.pack('<3f',*v.co))
    for f in o.data.polygons:
        h.update(struct.pack('<I',len(f.vertices)))
        for i in f.vertices:h.update(struct.pack('<I',i))
    return h.hexdigest()


def camera_record(scene):
    c=scene.camera
    return {'name':c.name,'matrix_world':[list(r) for r in c.matrix_world],
            'type':c.data.type,'ortho_scale':c.data.ortho_scale,
            'shift_x':c.data.shift_x,'shift_y':c.data.shift_y,
            'resolution':[scene.render.resolution_x,scene.render.resolution_y]}


def apply_mist_rework(bpy, scene):
    """Tune physical gas extinction and plume span, not alpha compositing.

    Source gas geometry remains mesh-based, translucent by volume scattering,
    with radial/axial falloff reaching zero well inside the mesh boundary.
    Wisp transforms remain closed at frame 97 and source frame 0 remains idle.
    """
    specs=(('SOLAR V4 | real feathered steam volume',6.8),
           ('SOLAR V4 | soft thin steam halo',3.6))
    updated_materials={}
    for name,gain in specs:
        material=bpy.data.materials[name]
        assert material.use_nodes
        volume=[n for n in material.node_tree.nodes if n.bl_idname=='ShaderNodeVolumePrincipled']
        assert len(volume)==1
        node=material.node_tree.nodes['V4 calibrated steam optical density']
        assert node.type=='MATH' and node.operation=='MULTIPLY'
        assert 0 < node.inputs[1].default_value < 2
        node.inputs[1].default_value=gain
        volume[0].inputs['Anisotropy'].default_value=.19
        material['solar_v4b_density_gain']=gain
        material['solar_v4b_role']='open-relief volume scattering, not opaque sphere or cone'
        updated_materials[name]=gain
    steam=[o for o in scene.objects if o.type=='MESH' and o.name.startswith('STEAM V4 | open relief | lobe ')]
    assert len(steam)==12
    for obj in steam:
        assert obj.get('emitter')=='open pressure relief valve only'
        is_veil=obj['steam_role']=='feather veil'
        for f in (0,*WORK,97):
            scene.frame_set(f)
            scale=obj.scale.copy()
            # Steam feather is tall and sinuous, never big opaque balls.
            obj.scale=(scale.x*(1.78 if is_veil else 1.52),
                       scale.y*(1.64 if is_veil else 1.52),
                       scale.z*(1.72 if is_veil else 1.58))
            obj.keyframe_insert(data_path='scale',frame=f)
        obj['solar_v4b_scattered_steam']=True
        obj['v4b_radius_envelope_relative']=1.78 if is_veil else 1.52
    scene.frame_set(0)
    return updated_materials,len(steam)


def render_scene(bpy,scene,destination,kind,direction,timeline):
    root=bpy.data.objects['EXPORT | rotate Solar Boiler model, never camera']
    root.rotation_euler.z=math.radians(DIRECTIONS[direction])
    scene.frame_set(timeline)
    bpy.context.view_layer.update()
    scene.render.filepath=str(destination)
    print('SOLAR_V4B_CYCLES_PROOF',destination.name,kind,direction,timeline,flush=True)
    bpy.ops.render.render(write_still=True)
    return {'file':destination.name,'state':kind,'direction':direction,'frame':timeline,'sha256':sha(destination)}


def build(options):
    import bpy
    self_check()
    if options.output.exists() and any(options.output.iterdir()):
        raise FileExistsError('Never overwrite reviewed source or proof directory')
    original_hash=sha(SOURCE)
    bpy.ops.wm.open_mainfile(filepath=str(SOURCE.resolve()))
    scene=bpy.context.scene
    root=bpy.data.objects['EXPORT | rotate Solar Boiler model, never camera']
    scene.frame_set(0);root.rotation_euler.z=0;bpy.context.view_layer.update()
    cam=camera_record(scene)
    assert len([o for o in bpy.data.objects if o.type=='CAMERA'])==1
    assert cam['name']=='FMPL_CAPTURE_CAMERA' and cam['type']=='ORTHO'
    refs=bpy.data.collections['REFERENCE ONLY | adjacent matched 1-tile pipe fixtures']
    assert refs.hide_render
    all_other={o.name:fingerprint(o) for o in scene.objects if o.type=='MESH' and not o.name.startswith('STEAM V4 | open relief | lobe ')}
    materials,count=apply_mist_rework(bpy,scene)
    for name,original in all_other.items():
        assert fingerprint(bpy.data.objects[name])==original,('Unrelated wood or pipe mesh changed',name)
    scene['solar_boiler_revision']='V4b physically visible 3D steam on wooden V4 boiler'
    scene['solar_v4b_source_v4_sha256']=original_hash
    scene['game_integration']=False
    scene.frame_start=0;scene.frame_end=97
    scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=options.samples
    scene.cycles.seed=5855;scene.cycles.use_animated_seed=False
    if hasattr(scene.cycles,'use_denoising'):scene.cycles.use_denoising=False
    for layer in scene.view_layers:
        if hasattr(layer.cycles,'use_denoising'):layer.cycles.use_denoising=False
    scene.render.film_transparent=True
    scene.render.resolution_x=scene.render.resolution_y=256
    scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG'
    scene.render.image_settings.color_mode='RGBA'
    scene.render.image_settings.color_depth='8'
    scene.render.threads_mode='FIXED';scene.render.threads=4
    scene.render.fps=8
    scene.frame_set(0);root.rotation_euler.z=0;bpy.context.view_layer.update()
    assert camera_record(scene)==cam
    options.output.mkdir(parents=True,exist_ok=True)
    bpy.ops.file.pack_all()
    native=options.output/'solar-boiler-v4b.blend'
    bpy.ops.wm.save_as_mainfile(filepath=str(native),check_existing=False,compress=True)
    report={'schema':'tanks.solar-boiler.v4b.relief-steam','status':'editable 3D steam refinement candidate',
            'source_v4_sha256':original_hash,'native_sha256':sha(native),
            'footprint':[3,2],'ports_unchanged':True,'wood_geometry_preserved':len(all_other),
            'steam_lobes':count,'no_steam_at_connected_pipes':True,
            'steam_material_gain':materials,'camera':cam,
            'frames':list(WORK),'working_fps':8,'renders':[],
            'visual_approved':False,'game_integrated':False}
    record=options.output/'build-report.json'
    record.write_text(json.dumps(report,indent=2)+'\n')
    if options.render=='none':return
    for d in range(4):
        report['renders'].append(render_scene(bpy,scene,options.output/f'idle-d{d:02d}.png','idle',d,0))
        report['renders'].append(render_scene(bpy,scene,options.output/f'working-d{d:02d}.png','working',d,25))
    if options.render=='pilot':
        for i,f in enumerate(WORK):
            report['renders'].append(render_scene(bpy,scene,options.output/f'loop-d00-f{i:03d}.png','working',0,f))
    # Real same-pose Cycles comparison: no curves muted or fake compositing.
    collection=bpy.data.collections['09 | V4 soft atmosphere steam relief only']
    scene.frame_set(25);root.rotation_euler.z=0;bpy.context.view_layer.update()
    for label,visible in (('off',False),('on',True)):
        collection.hide_render=not visible
        bpy.context.view_layer.update()
        img=options.output/f'steam-isolation-{label}.png'
        scene.render.filepath=str(img)
        bpy.ops.render.render(write_still=True)
        report.setdefault('isolation',[]).append({'file':img.name,'visible':visible,'sha256':sha(img)})
    collection.hide_render=False
    root.rotation_euler.z=0;scene.frame_set(0)
    record.write_text(json.dumps(report,indent=2)+'\n')
    assert sha(SOURCE)==original_hash
    print('SOLAR_V4B_READABLE_REAL_STEAM_RENDER_COMPLETE',len(report['renders']),flush=True)


def main():
    if '--self-check' in sys.argv:self_check();return
    p=argparse.ArgumentParser()
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--samples',type=int,default=24)
    p.add_argument('--render',choices=('none','proof','pilot'),default='pilot')
    opts=p.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:])
    assert 4<=opts.samples<=64
    build(opts)

if __name__=='__main__':main()
